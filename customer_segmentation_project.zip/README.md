
# Customer Segmentation Project

## Project Overview
This project segments customers based on demographics and purchasing behavior using Power BI and Python.

## Files Included
- customer_segmentation_dataset.csv
- customer_segmentation_dataset.xlsx
- customer_segmentation.py
- customer_segmentation_queries.sql

## Power BI Steps
1. Open Power BI Desktop
2. Click "Get Data" -> CSV
3. Load customer_segmentation_dataset.csv
4. Create charts:
   - Pie Chart: Segment Distribution
   - Bar Chart: Average Income by Segment
   - Scatter Plot: Income vs Spending Score
5. Add slicers for Gender and Region

## Suggested Dashboard KPIs
- Total Customers
- Average Income
- Average Spending Score
- Top Customer Segment

## GitHub Upload
1. Create a new repository
2. Upload all files
3. Add screenshots of your Power BI dashboard
