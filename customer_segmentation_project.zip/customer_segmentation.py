
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Load Dataset
data = pd.read_csv('customer_segmentation_dataset.csv')

# Select features
features = data[['AnnualIncome', 'SpendingScore', 'PurchaseFrequency']]

# Scale data
scaler = StandardScaler()
scaled = scaler.fit_transform(features)

# KMeans clustering
kmeans = KMeans(n_clusters=4, random_state=42)
data['Cluster'] = kmeans.fit_predict(scaled)

print(data.head())

# Save clustered output
data.to_csv('clustered_customers.csv', index=False)
print("Clustered file saved!")
