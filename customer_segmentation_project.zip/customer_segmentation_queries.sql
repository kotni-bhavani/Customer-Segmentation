
CREATE TABLE Customers (
    CustomerID INT,
    Age INT,
    Gender VARCHAR(10),
    AnnualIncome INT,
    SpendingScore INT,
    PurchaseFrequency INT,
    Region VARCHAR(20),
    Segment VARCHAR(50)
);

-- Example Query
SELECT Segment, AVG(AnnualIncome) AS AvgIncome
FROM Customers
GROUP BY Segment;
